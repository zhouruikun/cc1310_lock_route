/*
 * common.h
 *
 *  Created on: 2018��10��26��
 *      Author: Administrator
 */
#define DEBUG     1
#ifndef COMMON_ROUTE_H_
#define COMMON_ROUTE_H_
#define FRAME_HEADER_L 0x0E
#define FRAME_HEADER_H 0xFA
#define FRAME_END 0x16
#define PAYLOAD_LENGTH 128
#define WIR_STATUS_PAIR   1
#define WIR_STATUS_NOMAL   2
#define SEND_OPEN_DOOR 1
#define SEND_PAIR 2
#define MAX_PAIR_LOCK  10
typedef struct locksStruct{
    uint8_t lock_mac[6];
    uint32_t lock_rolling_code;
    uint8_t saved[6];
}locks_type;
typedef struct locks{
   locks_type locks_data[MAX_PAIR_LOCK];
   uint8_t locks_number;
}locks;
extern uint8_t send_msg ;
uint8_t get_crypt_pack( uint8_t *crypt_pack, uint8_t * logicMacAddress,uint32_t rolling_code, uint32_t random);
uint8_t get_crypt_data( uint8_t *crypted_pack, uint8_t *logicMacAddress,uint32_t *rolling_code,uint32_t *random);
uint8_t checkPack( uint8_t* buff, size_t size);
uint8_t getCheckSum( uint8_t* buff, size_t size);
void setLogicMac( uint64_t PHY_Mac);
uint8_t send_pair_response(uint8_t * to,uint8_t status);
void pairKeyPressed(void);
void resetKeyPressed(void);
void openDoorKeyPressed(void);
void wirToLock( uint8_t* buff, size_t size);
void lockToWir(char * buffin,size_t size_in);
void readLockData(void);
void saveLockData(void);
uint8_t isPaired(uint8_t* mac);
void sendCrypedPack(uint8_t to,uint8_t param);
uint8_t addPairedLock(uint8_t* mac);
uint8_t send_syc_response(uint8_t from,uint8_t * buff);
uint8_t get_wir_status(void);
void set_wir_status(uint8_t sta);
void checkPair(void);
uint8_t removePairedLock(uint8_t lockid);
#endif /* COMMON_ROUTE_H_ */
