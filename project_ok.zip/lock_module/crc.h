/*
 * crc.h
 *
 *  Created on: 2018��11��13��
 *      Author: Administrator
 */

#ifndef CRC_H_
#define CRC_H_

uint8_t CRC48( uint8_t *crc_out,uint8_t *data, uint32_t len );

#endif /* CRC_H_ */
