/*
 * common.h
 *
 *  Created on: 2018��10��26��
 *      Author: Administrator
 */
#define DEBUG     1
#ifndef COMMON_NODE_H_
#define COMMON_NODE_H_
#define FRAME_HEADER_L 0x0E     //�ⲿЭ��
#define FRAME_HEADER_H 0xFA
#define FRAME_HEADER_LOCK_L 0x01 //�ڲ�Э��
#define FRAME_HEADER_LOCK_H 0xFA
#define TO_LOCK   1
#define TO_WIR    0
#define PIN_IN 0
#define PIN_OUT 1
#define FRAME_END 0x16
#define PAYLOAD_LENGTH 128
#define STATUS_WORKING 2
#define STATUS_SLEEPING 3
#define SLEEP_TIMES         2
#define WAKE_TIMES          5
typedef struct {
    uint32_t rolling_code;
   uint8_t locks_status;
   uint8_t save[11];
}locks_status_type;
uint8_t checkPack( uint8_t* buff, size_t size,uint8_t dir);
uint8_t getCheckSum( uint8_t* buff, size_t size);
void setLogicMac( uint64_t PHY_Mac);
uint8_t send_pair_request( void);
uint8_t get_pair_response(uint8_t para1,uint16_t para2);
uint8_t wifi_status_response(void);
uint8_t get_crypt_data( uint8_t *crypted_pack, uint8_t *logicMacAddress,uint32_t *rolling_code,uint32_t *random);
void read_rolling_code(void);
uint8_t send_syc_request(void);
uint8_t get_fleep_flag(void);
void set_fleep_flag(uint8_t flag);
void set_pin_mode(uint8_t mode);
#endif /* COMMON_NODE_H_ */
