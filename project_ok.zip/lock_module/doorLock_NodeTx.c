/*
 * Copyright (c) 2016-2017, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/***** Includes *****/
#include <stdlib.h>

/* XDCtools Header files */
#include <xdc/std.h>
#include <xdc/runtime/Assert.h>

/* BIOS Header files */
#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Semaphore.h>
#include <ti/sysbios/knl/Task.h>

/* TI-RTOS Header files */
#include <ti/drivers/rf/RF.h>
#include <ti/drivers/PIN.h>
#include <ti/drivers/uart.h>
#include <ti/display/Display.h>
#include <ti/devices/cc13x0/driverlib/crypto.h>
#include <ti/drivers/power/PowerCC26XX.h>
/* Board Header files */
#include "Board.h"
#include <common_node.h>
/* RF settings */
#include "smartrf_settings/smartrf_settings.h"

/***** Defines *****/
#define MAX_UART PAYLOAD_LENGTH
/* Wake-on-Radio configuration */
#define WOR_WAKEUPS_PER_SECOND 20

/* TX number of random payload bytes */


/* WOR Example configuration defines */
#define WOR_PREAMBLE_TIME_RAT_TICKS(x) \
    ((uint32_t)(4000000*(1.0f/(x))))

/* TX task stack size and priority */
#define TX_TASK_STACK_SIZE 1024
#define TX_TASK_PRIORITY   2
#define UART_TASK_STACK_SIZE 1024
#define UART_TASK_PRIORITY   4

/***** Prototypes *****/
static void txTaskFunction(UArg arg0, UArg arg1);
static void initializeTxAdvCmdFromTxCmd(rfc_CMD_PROP_TX_ADV_t* RF_cmdPropTxAdv, rfc_CMD_PROP_TX_t* RF_cmdPropTx);


/***** Variable declarations *****/
/* TX task objects and task stack */
static Task_Params txTaskParams;
Task_Struct txTask;    /* not static so you can see in ROV */
static uint8_t txTaskStack[TX_TASK_STACK_SIZE];
static Task_Params uartTaskParams;
Task_Struct uartTask;    /* not static so you can see in ROV */

char        input[MAX_UART];
const char  echoPrompt[] = "Echoing characters:\r\n";
static uint8_t uartTaskStack[UART_TASK_STACK_SIZE];
UART_Handle uart;
UART_Params uartParams;


const PIN_Config uartpinsleep[] = {
                                 /* UART RX via debugger back channel */
    CC1310_LAUNCHXL_UART_TX | PIN_INPUT_EN  | PIN_PULLDOWN,                        /* UART TX via debugger back channel */
    PIN_TERMINATE
};
const PIN_Config uartpinwork[] = {
    CC1310_LAUNCHXL_UART_RX | PIN_INPUT_EN | PIN_PULLDOWN,                                              /* UART RX via debugger back channel */
    CC1310_LAUNCHXL_UART_TX | PIN_GPIO_OUTPUT_EN | PIN_GPIO_HIGH | PIN_PUSHPULL,                        /* UART TX via debugger back channel */
    PIN_TERMINATE
};
PIN_Handle uartpinHandle;
PIN_State uartpinState;
/* TX packet payload (length +1 to fit length byte) and sequence number */
uint8_t packet[PAYLOAD_LENGTH +1];


/* RF driver objects and handles */
static RF_Object rfObject;
extern RF_Handle rfHandle;

/* Pin driver objects and handles */
extern PIN_Handle outPinHandle;
extern  PIN_Handle inPinHandle;
extern PIN_State outPinState;
extern  PIN_State buttonPinState;
extern uint8_t WOR_WAKEUPS_PER_SECOND_rx;
/* TX Semaphore */
static Semaphore_Struct txSemaphore;
Semaphore_Handle txSemaphoreHandle;
static void uartTaskFunction(UArg arg0, UArg arg1);
/* Advanced TX command for sending long preamble */
rfc_CMD_PROP_TX_ADV_t RF_cmdPropTxAdv;

/*user defined */
extern uint64_t macAddress;

/***** Function definitions *****/

extern void rxTaskInit();
/* Pin interrupt Callback function board buttons configured in the pinTable. */
void buttonCallbackFunction(PIN_Handle handle, PIN_Id pinId) {
    int_fast32_t temp=0;
    /* Simple debounce logic, only toggle if the button is still pushed (low) */

//    if (!PIN_getInputValue(pinId)) {
    if ( (pinId)==Board_PIN_D_CE) {
        while(!PIN_getInputValue(pinId))
        {
            CPUdelay((uint32_t)((48000000/4)*0.010f));
            temp++;
            if(temp>10)
            {
                PIN_setOutputValue(outPinHandle, IOID_12, 0);
//                usleep(10000);
                CPUdelay((uint32_t)((48000000/4)*0.110f));
                PIN_setOutputValue(outPinHandle, IOID_12, 1);
                /* Post TX semaphore to TX task */
                Semaphore_post(txSemaphoreHandle);
                break;
            }


        }

    }
}
void uartTaskInit()
{
    /* Initialize TX semaphore */


    Semaphore_construct(&txSemaphore, 0, NULL);
    txSemaphore.f2 = ti_sysbios_knl_Semaphore_Mode_BINARY;
    txSemaphoreHandle = Semaphore_handle(&txSemaphore);

    Task_Params_init(&uartTaskParams);
    uartTaskParams.stackSize = UART_TASK_STACK_SIZE;
    uartTaskParams.priority = UART_TASK_PRIORITY;
    uartTaskParams.stack = &uartTaskStack;
    Task_construct(&uartTask, uartTaskFunction, &uartTaskParams, NULL);
}
static void uartTaskFunction(UArg arg0, UArg arg1)
{
    PIN_Config myPinConfig;
    static int_fast32_t rec_cnt=0;
    /* Call driver init functions */
    UART_init();

    /* Create a UART with data processing off. */
    UART_Params_init(&uartParams);
    uartParams.writeDataMode = UART_DATA_BINARY;
    uartParams.readDataMode = UART_DATA_BINARY;
    uartParams.readReturnMode = UART_RETURN_FULL;
    uartParams.readEcho = UART_ECHO_OFF;
    uartParams.baudRate = 115200;
    uartParams.readTimeout = 500;
    uart = UART_open(Board_UART0, &uartParams);
    if (uart == NULL) {
        /* UART_open() failed */
        while (1);
    }
    while(1)
       {
        /* Wait for a button press */
        UART_close(uart);
        //set tx as input with pull up
        uartpinHandle= PIN_open(&uartpinState, uartpinsleep);
        Semaphore_pend(txSemaphoreHandle, BIOS_WAIT_FOREVER);
        PIN_close(uartpinHandle);
        uart = UART_open(Board_UART0, &uartParams);
        WOR_WAKEUPS_PER_SECOND_rx=WAKE_TIMES;
        set_fleep_flag(STATUS_WORKING);
        while(1)
        {
            //ָ���ж��Ƿ�����
            if (get_fleep_flag()== STATUS_SLEEPING)
            {
                usleep(1000);
                Semaphore_reset(txSemaphoreHandle,0);
                WOR_WAKEUPS_PER_SECOND_rx=SLEEP_TIMES;
                break;
            }
            //���ڶ�ȡ����
              rec_cnt =  UART_read(uart, input, 1);
              if(rec_cnt>0)
              {
                  rec_cnt = UART_read(uart, input+1, MAX_UART);
                  rec_cnt+=1;
                  lockToWir(input,rec_cnt);//�������˵���ƵЭ�鴦������
              }
        }

       }
}

/* TX task initialization function. Runs once from main() */
void txTaskInit()
{


    /* Initialize and create TX task */
    Task_Params_init(&txTaskParams);
    txTaskParams.stackSize = TX_TASK_STACK_SIZE;
    txTaskParams.priority = TX_TASK_PRIORITY;
    txTaskParams.stack = &txTaskStack;
    Task_construct(&txTask, txTaskFunction, &txTaskParams, NULL);
}

/* TX task function. Executed in Task context by TI-RTOS when the scheduler starts. */
static void txTaskFunction(UArg arg0, UArg arg1)
{
    /* Initialize the radio */
    RF_Params rfParams;
    RF_Params_init(&rfParams);

    /* Initialize TX_ADV command from TX command */
    initializeTxAdvCmdFromTxCmd(&RF_cmdPropTxAdv, &RF_cmdPropTx);

    /* Set application specific fields */
    RF_cmdPropTxAdv.pktLen = PAYLOAD_LENGTH +1; /* +1 for length byte */
    RF_cmdPropTxAdv.pPkt = packet;
    RF_cmdPropTxAdv.preTrigger.triggerType = TRIG_REL_START;
    RF_cmdPropTxAdv.preTime = WOR_PREAMBLE_TIME_RAT_TICKS(WOR_WAKEUPS_PER_SECOND);

    /* Request access to the radio */
//    rfHandle = RF_open(&rfObject, &RF_prop, (RF_RadioSetup*)&RF_cmdPropRadioDivSetup, &rfParams);
//
//    /* Set the frequency */
//    RF_runCmd(rfHandle, (RF_Op*)&RF_cmdFs, RF_PriorityNormal, NULL, 0);

    /* Enter main TX loop */
//    while(1)
    {
        usleep(10000);
//         /* Wait for a button press */
//         Semaphore_pend(txSemaphoreHandle, BIOS_WAIT_FOREVER);
//
//         /* Create packet with incrementing sequence number and random payload */
//         packet[0] = PAYLOAD_LENGTH;
//         packet[1] = (uint8_t)(11 >> 8);
//         packet[2] = (uint8_t)(11 );
//         uint8_t i;
//         for (i = 3; i < PAYLOAD_LENGTH +1; i++)
//         {
//             packet[i] = rand();
//         }
//
//         /* Send packet */
//         RF_runCmd(rfHandle, (RF_Op*)&RF_cmdPropTxAdv, RF_PriorityNormal, NULL, 0);
//
//        /* Toggle LED */
//        PIN_setOutputValue(ledPinHandle, Board_PIN_LED1, !PIN_getOutputValue(Board_PIN_LED1));
    }
}

/* Copy the basic RX configuration from CMD_PROP_RX to CMD_PROP_RX_SNIFF command. */
static void initializeTxAdvCmdFromTxCmd(rfc_CMD_PROP_TX_ADV_t* RF_cmdPropTxAdv, rfc_CMD_PROP_TX_t* RF_cmdPropTx)
{
    #define RADIO_OP_HEADER_SIZE 14

    /* Copy general radio operation header from TX commmand to TX_ADV */
    memcpy(RF_cmdPropTxAdv, RF_cmdPropTx, RADIO_OP_HEADER_SIZE);

    /* Set command to CMD_PROP_TX_ADV */
    RF_cmdPropTxAdv->commandNo = CMD_PROP_TX_ADV;

    /* Copy over relevant parameters */
    RF_cmdPropTxAdv->pktConf.bFsOff = RF_cmdPropTx->pktConf.bFsOff;
    RF_cmdPropTxAdv->pktConf.bUseCrc = RF_cmdPropTx->pktConf.bUseCrc;
    RF_cmdPropTxAdv->syncWord = RF_cmdPropTx->syncWord;
}


///*
// *  ======== main ========
// */
//int main(void)
//{
//    /* Call driver init functions. */
//    Board_initGeneral();
//    Display_init();
//
//    /* Open LED pins */
//    ledPinHandle = PIN_open(&ledPinState, pinTable);
//    Assert_isTrue(ledPinHandle != NULL, NULL);
//
//    /* Open Button pins */
//    buttonPinHandle = PIN_open(&buttonPinState, );
//    Assert_isTrue(buttonPinHandle != NULL, NULL);
//
//    /* Initialize task */
//    txTaskInit();
//    /* Initialize task */
//    rxTaskInit();
//    uartTaskInit();
//    /* Start BIOS */
//    BIOS_start();
//
//    return (0);
//}
